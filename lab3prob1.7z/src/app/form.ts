export class Form
{
    constructor(id:number,
    name:string,
    cost:number,
    online:boolean,
    category:string,
    store:string){}
}