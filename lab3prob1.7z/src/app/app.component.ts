import { Component } from '@angular/core';
import { NgForm } from '@angular/forms'
import { Form } from './form'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  submitted = false;
  flagBlur: boolean = false;
  categories = ['Grocery', 'Mobile', 'Electronics', 'Cloths'];
  data = new Form(null, '', null, false, this.categories[0], null)
  
  onSubmit(myForm: NgForm) {
    
      console.log("Form submitted");
      console.log("Product ID:"+myForm.value.productid);
      console.log("Product Category:"+myForm.value.catgeory);
      console.log("Product Online option:"+myForm.value.onlineoption);
      console.log("Available in stores: ");
      if(myForm.value.BigBazar)
      {console.log("Big Bazar")}
      if(myForm.value.DMart)
      {console.log("D Mart")}
      if(myForm.value.Reliance)
      {console.log("Reliance")}
      if(myForm.value.MegaStore)
      {console.log("Mega Store")}
      

  

  }
}
