import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-addmovies',
  templateUrl: './addmovies.component.html',
  styleUrls: ['./addmovies.component.css']
})
export class AddmoviesComponent implements OnInit {

  constructor() { }
  formdata;
  movieName:FormControl;
  movieRating:FormControl;
  movieGenere:FormControl;
  ngOnInit() {
    this.movieName = new FormControl("",Validators.compose([
            Validators.required,Validators.pattern("[a-zA-Z0-9 ]+")]));
      this.movieRating= new FormControl("",Validators.compose([
            Validators.required,Validators.max(5),Validators.min(0)]));
      this.movieGenere= new FormControl("",Validators.compose([
            Validators.required]));
    this.formdata = new FormGroup({
      movieName:this.movieName,
      movieRating:this.movieRating,
      movieGenere:this.movieGenere
    });

  }

}
