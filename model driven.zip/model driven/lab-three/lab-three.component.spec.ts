import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LabThreeComponent } from './lab-three.component';

describe('LabThreeComponent', () => {
  let component: LabThreeComponent;
  let fixture: ComponentFixture<LabThreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LabThreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LabThreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
