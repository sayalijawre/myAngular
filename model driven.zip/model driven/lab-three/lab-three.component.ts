import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-lab-three',
  templateUrl: './lab-three.component.html',
  styleUrls: ['./lab-three.component.css']
})
export class LabThreeComponent implements OnInit {
  
  constructor() { }
  formdata;
  ngOnInit() {
    this.formdata = new FormGroup({
         productid: new FormControl("",Validators.compose([
            Validators.required])),
         prodName: new FormControl("",Validators.compose([
            Validators.required])),
         prodCost : new FormControl("",Validators.compose([
            Validators.required])),
         prodOnline : new FormControl("",Validators.compose([
            Validators.required])),
         prodCat : new FormControl("",Validators.compose([
            Validators.required])),
         prodStore: new FormControl(),
         prodStore2: new FormControl(),
         prodStore3: new FormControl(),
         prodStore4: new FormControl()
      });
  }

  onClickSubmit(data) {
    console.log("Product Id is :" + data.productid);
    console.log("Product Name is :" + data.prodName);
    console.log("Product Cost is :" + data.prodCost);
    console.log("Is Product Online :" + data.prodOnline);
    console.log("Product Category is :" + data.prodCat);
    console.log("Product Id is :" + data.productid);
    console.log("Available in stores : ");
    
    if(data.prodStore)
    console.log("Big Bazar");
    if(data.prodStore2)
    console.log("DMart");
    if(data.prodStore3)
    console.log("Reliance");
    if(data.prodStore4)
    console.log("Mega Store");

   }

}
