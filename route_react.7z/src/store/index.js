import {createStore} from 'redux';

const initialState={
    count:3
};

const reducer=(state=[],action)=>{
    console.log('reducer unning',action);
    switch(action.type){
        case 'INCREMENT':
        state=state.concat (action.payload);
        break;
        default:
        return state;
    }
    return state;
}

const store= createStore(reducer);

export default store;