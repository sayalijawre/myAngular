import React from 'react';
import {connect} from 'react-redux';

function Counter(props)
{
    return(
        <div>
            <h1>I am counter!</h1>
            <p>Count: {props.count}</p>
            <input type='text' ref='task'/>
            <button onClick={props.onIncrementClick(this.refs.task.value)}>increment</button>
        </div>
    )
}

function Task(props){
    return(
        <div>
            <tr>
                <td>{this.props.task}</td>
            </tr>
        </div>
    )
}

function mapStateToProps(state){
    console.log('mapStateToProps',state);
    return{
        count:state.count
    }
}

function mapDispatchToProps(dispatch){
    return{
        onIncrementClick:(task)=>{
            console.log('clicked...');
            const action={type:'INCREMENT',payload:task};
            dispatch(action);
        }
    }
}

export default connect(mapStateToProps,mapDispatchToProps,Task)(Counter);