import { Component, OnInit } from '@angular/core';
import {User} from './form';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  title = 'Angular 2 operation';
  user:User={
    id: null,
    name:'',
    salary:null ,
    department:''
  };
  onAdd(a,b,c,d)
  {
    alert(a+" "+ b+" "+ c+" "+ d)
  }

}
