import { Component, OnInit } from '@angular/core';
import {ConfigService} from '../config.service';
import {Config} from './configInt';
import {ConfigPipe} from './config.pipe';
import {ConfigTitlePipe} from './config-title.pipe';
import {ConfigYearPipe} from './config-year.pipe';
import {ConfigauthorPipe} from './configauthor.pipe';

@Component({
  selector: 'app-config',
  templateUrl: './config.component.html',
  styleUrls: ['./config.component.css'],
 
})
export class ConfigComponent implements OnInit {
  config: Config[];

  idFilter:string='';
  titleFilter:string='';
  yearFilter:string='';
  authorFilter: string='';

  constructor(private configService:ConfigService) { }

  ngOnInit() {
    this.getConfig();
    console.log(this.config);
  
}
getConfig():void{
  this.configService.getConfig().subscribe(config=>this.config=config);
}

}
