export class User
{
    id:number;
    name:string;
    salary:number;
    department:string;
}

