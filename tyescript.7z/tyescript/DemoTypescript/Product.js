var All;
(function (All) {
    var IProduct = (function () {
        function IProduct() {
        }
        return IProduct;
    }());
    All.IProduct = IProduct;
})(All || (All = {}));
