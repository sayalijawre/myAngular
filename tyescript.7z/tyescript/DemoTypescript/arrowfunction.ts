let log=function(message){
    
    console.log('Welcome to Arrow');
}
//Arrow function equivalent to above function 
let doLog=(message)=>console.log(message);

//Arrow function equivalent to no parameter  function 
let withoutparameter=()=>console.log();