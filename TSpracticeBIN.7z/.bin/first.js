document.write("Hello!!!!!");
var myName = "Sayali";
var age = 21;
var canVote = true;
var anything = "Capgemini";
document.getElementById("name").innerHTML = "I am " + myName;
document.write("</br>type of name: " + typeof (myName));
document.write("</br>type of age: " + typeof (age));
document.write("</br>type of boolean: " + typeof (canVote));
document.write("</br>type of anything: " + typeof (anything));
var pi = 3.14;
document.write("</br>pi is a " + typeof (pi) + " " + pi);
var strToNum = parseInt("aa");
var numToString = 5;
document.write("</br>String to number: " + typeof (strToNum) + " " + strToNum);
document.write("</br>number to string: " + typeof (numToString) + " " + numToString);
var myArray = [9, 1, 3, 9];
for (var pos in myArray) {
    document.write("</br>postion: " + pos);
}
for (var _i = 0, myArray_1 = myArray; _i < myArray_1.length; _i++) {
    var val = myArray_1[_i];
    document.write("</br>value: " + val);
}
var mappedArray = myArray.map(Math.sqrt);
for (var _a = 0, mappedArray_1 = mappedArray; _a < mappedArray_1.length; _a++) {
    var mapVal = mappedArray_1[_a];
    document.write("</br>value: " + mapVal);
}
var addOne = function (x) { return (x + 1); };
console.log(addOne(1));
var GetSum = function (num1, num2) {
    return num1 + num2;
};
var ans = GetSum(2, 7);
document.write("</br>Addition is : " + ans);
var total = [2, 3, 5].reduce(function (a, b) { return a + b; });
document.write("</br>Answer: " + total);
//-----------------multiple input-----------
var sumAll = function () {
    var nums = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        nums[_i] = arguments[_i];
    }
    var sum = nums.reduce(function (a, b) { return a + b; });
    document.write("</br>" + sum);
};
sumAll(2, 2);
sumAll(2, 4, 6);
//-------------------Class----------
var Emp = /** @class */ (function () {
    function Emp() {
        var _this = this;
        this.Name = "Sayali";
        this.getName = function () {
            return _this.Name;
        };
        this.setName = function (name) { _this.Name = name; };
    }
    return Emp;
}());
var e1 = new Emp();
console.log(e1.getName());
e1.setName("Jawre");
console.log(e1.getName());
console.log(e1.Name);
