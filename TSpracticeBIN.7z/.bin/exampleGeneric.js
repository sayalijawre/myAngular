/*class Aclass<T>
{
    Add(v1:T,v2:T):any
    {
        return v1+v2;
    }
}

var obj=new Aclass<number>();
obj.Add(2,3)*/
function GetType(val) {
    return typeof (val);
}
GetType(3);
