var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Animal = /** @class */ (function () {
    function Animal(name, owner) {
        this.favFood = "meat";
        this._weight = 100;
        this.name = name;
        this.owner = owner;
        Animal.numOfAnimal++;
    }
    Object.defineProperty(Animal.prototype, "weight", {
        get: function () {
            return this._weight;
        },
        enumerable: true,
        configurable: true
    });
    /*  set weight(w:number)
      {
          this._weight=w;
      }
  */
    Animal.prototype.ownerInfo = function () {
        console.log("Animal name: " + this.name + " Owner is: " + this.owner + " Fav food is: " + this.favFood);
    };
    Animal.numOfAnimal = 0;
    return Animal;
}());
console.log(Animal.numOfAnimal);
var A1 = new Animal("Tom", "Abc");
A1.ownerInfo();
//A1.weight=100;
console.log(A1.weight);
console.log(Animal.numOfAnimal);
var A2 = new Animal("Cat", "Xyz");
A2.ownerInfo();
//A2.weight=100;
console.log(A2.weight);
console.log(Animal.numOfAnimal);
//--------------Inheritance----------------
var DomesticAnimals = /** @class */ (function (_super) {
    __extends(DomesticAnimals, _super);
    function DomesticAnimals(_typeOfWork, name, owner) {
        var _this = _super.call(this, name, owner) || this;
        _this._typeOfWork = _typeOfWork;
        return _this;
    }
    Object.defineProperty(DomesticAnimals.prototype, "typeOfWork", {
        get: function () {
            return this._typeOfWork;
        },
        set: function (t) {
            this._typeOfWork = t;
        },
        enumerable: true,
        configurable: true
    });
    DomesticAnimals.prototype.animalInfo = function () {
        console.log("Animal name: " + this.name + " Owner is: " + this.owner + "Type of work: " + this._typeOfWork);
    };
    return DomesticAnimals;
}(Animal));
var Cat = new DomesticAnimals("Sleeping", "Tommy", "ABCD");
Cat.animalInfo();
Cat.typeOfWork = "eating";
Cat.animalInfo();
