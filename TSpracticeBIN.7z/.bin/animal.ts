class Animal
{
    favFood:string="meat";
   name:string;
   owner:string;
    static numOfAnimal:number=0;
    _weight:number=100;
    
    constructor(name:string,owner:string){  //since private is used no need of declaring variables and due to hoisting thi decalaration move to the top!!!
        this.name=name;
        this.owner=owner;
        Animal.numOfAnimal++;
    }
    get weight():number{
        return this._weight;
    }
  /*  set weight(w:number)
    {
        this._weight=w;
    }
*/
    ownerInfo(){
        console.log("Animal name: "+this.name+" Owner is: "+this.owner+" Fav food is: "+this.favFood);
    }


}
console.log(Animal.numOfAnimal);
var A1=new Animal("Tom","Abc");
A1.ownerInfo();
//A1.weight=100;
console.log(A1.weight);

console.log(Animal.numOfAnimal);
var A2=new Animal("Cat","Xyz");
A2.ownerInfo();
//A2.weight=100;
console.log(A2.weight);

console.log(Animal.numOfAnimal);

//--------------Inheritance----------------

class DomesticAnimals extends Animal
{
    constructor(private _typeOfWork:string, name, owner)
    {
        super(name,owner);
    
    }
    get typeOfWork():string
    {
        return this._typeOfWork;
    }
    set typeOfWork(t:string)
    {
        this._typeOfWork=t;
    }
    animalInfo()
    {
        console.log("Animal name: "+this.name+" Owner is: "+this.owner+"Type of work: "+this._typeOfWork);
    }
}
var Cat= new DomesticAnimals("Sleeping","Tommy","ABCD");
Cat.animalInfo();
Cat.typeOfWork="eating";
Cat.animalInfo();