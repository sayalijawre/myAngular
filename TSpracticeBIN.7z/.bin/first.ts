document.write("Hello!!!!!");
var myName:string="Sayali";
var age:number=21;
var canVote:boolean=true;
var anything:any="Capgemini";

document.getElementById("name").innerHTML="I am "+myName;

document.write("</br>type of name: "+typeof(myName));
document.write("</br>type of age: "+typeof(age));
document.write("</br>type of boolean: "+typeof(canVote));
document.write("</br>type of anything: "+typeof(anything));

const pi=3.14;
document.write("</br>pi is a "+typeof(pi)+" "+pi);

var strToNum:number=parseInt("aa");
var numToString:number=5;
document.write("</br>String to number: "+typeof(strToNum)+" "+strToNum);
document.write("</br>number to string: "+typeof(numToString)+" "+numToString);

var myArray=[9,1,3,9];
for(var pos in myArray)
{
document.write("</br>postion: "+pos);
}
for(var val of myArray)
{
document.write("</br>value: "+val);
}


var mappedArray=myArray.map(Math.sqrt);
for(var mapVal of mappedArray)
{
document.write("</br>value: "+mapVal);
}
var addOne=(x)=>(x+1)
console.log(addOne(1));

var GetSum=function(num1:number,num2:number):number
{
    return num1+num2;
}
var ans:number=GetSum(2,7);
document.write("</br>Addition is : "+ans);

var total=[2,3,5].reduce((a,b)=>a+b);
document.write("</br>Answer: "+total);

//-----------------multiple input-----------

var sumAll=function(...nums:number[]):void
{
    var sum=nums.reduce((a,b)=>a+b);
    document.write("</br>"+sum)
}
sumAll(2,2);
sumAll(2,4,6);

//-------------------Class----------

class Emp{
    private Name:string="Sayali";
    getName=():string=>
    {
        return this.Name
    }
    setName=(name:string):void=> {this.Name=name;}
      
    

}
var e1=new Emp();
console.log(e1.getName());
e1.setName("Jawre");
console.log(e1.getName());
console.log(e1.Name);