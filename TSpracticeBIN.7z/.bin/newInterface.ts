interface SuperHero{
    superName:string;
    realName:string;
}
var sm:SuperHero={
    realName:"Amitabh",
    superName:"BigB"
}
document.write(""+sm.realName+"</br>"+sm.superName);

var superH:SuperHero[]=[];
superH.push({ realName:"ABC",
    superName:"XYZ"});
document.write("</br>"+superH[0].realName);
