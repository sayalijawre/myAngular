class Car
{
    isInNeutral:boolean;
    speed:number=50;
    start(isInNeutral)
    {
        if(isInNeutral==true)
        {
            console.log("Car started...")
        }
        else{
            console.log("Bring the car to neutarl state!")
        }

    }    
    stop()
    {
        console.log("Car stopped...")
    }
    increaseSpeed()
    {
        this.speed=this.speed+10
        console.log("Speed increased to: "+this.speed)
    }
    decreaseSpeed()
    {
        this.speed=this.speed-10
        console.log("Speed decreased to: "+this.speed)
    }
}

var Santro=new Car();
Santro.start(true);
Santro.increaseSpeed();
Santro.decreaseSpeed();

var Audi=new Car();
Audi.start(false);
Audi.increaseSpeed();
Audi.decreaseSpeed();