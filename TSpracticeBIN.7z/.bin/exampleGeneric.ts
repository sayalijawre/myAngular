/*class Aclass<T>
{
    Add(v1:T,v2:T):any
    {
        return v1+v2;
    }
}

var obj=new Aclass<number>();
obj.Add(2,3)*/
function GetType<T>(val:T):string
{
    return typeof(val);
}

GetType<number>(3)