class Human{
    FN:string;
    LN:string;
    Age:number;
    Height:number;
    constructor(FN:string,LN:string,Age:number,Height:number)
    {
        this.FN=FN;
        this.LN=LN;
        this.Age=Age;
        this.Height=Height;
    }
    Walk(){
       document.write("</br>Walking...");
    }
    Talk(){
       document.write("</br>Talking...");
    }
    Run(){
       document.write("</br>Running...");
    }
    ShowDetails()
    {
        document.write("First name:"+this.FN+"</br> Last Name:"+this.LN+"</br> Age:"+this.Age+"</br> Height:"+this.Height);
        this.Talk();
        this.Walk();
        this.Run();
    }
}

class Employee extends Human
{
    EID:number;
    Dept:string;
    Salary:number;
    DOJ:string;
    constructor(EID:number,Dept:string,Salary:number,DOJ:string,FN,LN,Age,Height)
    {
        super(FN,LN,Age,Height);
        this.EID=EID;
        this.Dept=Dept;
        this.Salary=Salary;
        this.DOJ=DOJ;
    }
    Code()
    {
        document.write("</br>Code...");
    }
    ReviewCode()
    {
        document.write("</br>Reviewing code...");
    }
    ApplyForLeave()
    {
        document.write("</br>Applied for leave...");
    }
    ShowDetails()
    {
        document.write("</br>******************************</br>");
        document.write("First name:"+this.FN+"</br> Last Name:"+this.LN+"</br> Age:"+this.Age+"</br> Height:"+this.Height+"</br>EID:"+this.EID+"</br>Department:"+this.Dept+"</br>Salary:"+this.Salary+"</br>DOJ:"+this.DOJ);
        this.Code();
        this.ReviewCode();
        this.ApplyForLeave();
    }
}

class Manager extends Employee
{
    ManagerOfTeam:string;
    constructor(ManagerOfTeam:string,EID,Dept,Salary,DOJ,FN,LN,Age,Height)
    {
        super(EID,Dept,Salary,DOJ,FN,LN,Age,Height)
        this.ManagerOfTeam=ManagerOfTeam;
    }
    GenerateReport()
    {
        document.write("</br>Report is being generated...");
    }
    AssignTaskToTeamMembers()
    {
        document.write("</br>Assigned task to team members...");
    }
    ApproveLeave()
    {
        document.write("</br>Approved the leave...");
    }
     ShowDetails()
    {
        document.write("</br>******************************");
        document.write("</br>Manager of team:"+this.ManagerOfTeam+"</br>First name:"+this.FN+"</br>Last Name:"+this.LN+"</br>Age:"+this.Age+"</br>Height:"+this.Height+"</br>EID:"+this.EID+"</br>Department:"+this.Dept+"</br>Salary:"+this.Salary);
        this.GenerateReport();
        this.AssignTaskToTeamMembers();
        this.ApplyForLeave();
    }

}

var h1=new Human("Sayali","Jawre",21,150);
h1.ShowDetails();

var e1=new Employee(123,"IT",12345,"21/07/2000","ABC","XYZ",50,155);
e1.ShowDetails();

var m1=new Manager("Java",987,"IT",98765,"23/9/2001","surabhi","Kulkarni",23,150);
m1.ShowDetails();