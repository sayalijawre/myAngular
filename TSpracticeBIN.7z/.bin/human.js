var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Human = /** @class */ (function () {
    function Human(FN, LN, Age, Height) {
        this.FN = FN;
        this.LN = LN;
        this.Age = Age;
        this.Height = Height;
    }
    Human.prototype.Walk = function () {
        document.write("</br>Walking...");
    };
    Human.prototype.Talk = function () {
        document.write("</br>Talking...");
    };
    Human.prototype.Run = function () {
        document.write("</br>Running...");
    };
    Human.prototype.ShowDetails = function () {
        document.write("First name:" + this.FN + "</br> Last Name:" + this.LN + "</br> Age:" + this.Age + "</br> Height:" + this.Height);
        this.Talk();
        this.Walk();
        this.Run();
    };
    return Human;
}());
var Employee = /** @class */ (function (_super) {
    __extends(Employee, _super);
    function Employee(EID, Dept, Salary, DOJ, FN, LN, Age, Height) {
        var _this = _super.call(this, FN, LN, Age, Height) || this;
        _this.EID = EID;
        _this.Dept = Dept;
        _this.Salary = Salary;
        _this.DOJ = DOJ;
        return _this;
    }
    Employee.prototype.Code = function () {
        document.write("</br>Code...");
    };
    Employee.prototype.ReviewCode = function () {
        document.write("</br>Reviewing code...");
    };
    Employee.prototype.ApplyForLeave = function () {
        document.write("</br>Applied for leave...");
    };
    Employee.prototype.ShowDetails = function () {
        document.write("</br>******************************</br>");
        document.write("First name:" + this.FN + "</br> Last Name:" + this.LN + "</br> Age:" + this.Age + "</br> Height:" + this.Height + "</br>EID:" + this.EID + "</br>Department:" + this.Dept + "</br>Salary:" + this.Salary + "</br>DOJ:" + this.DOJ);
        this.Code();
        this.ReviewCode();
        this.ApplyForLeave();
    };
    return Employee;
}(Human));
var Manager = /** @class */ (function (_super) {
    __extends(Manager, _super);
    function Manager(ManagerOfTeam, EID, Dept, Salary, DOJ, FN, LN, Age, Height) {
        var _this = _super.call(this, EID, Dept, Salary, DOJ, FN, LN, Age, Height) || this;
        _this.ManagerOfTeam = ManagerOfTeam;
        return _this;
    }
    Manager.prototype.GenerateReport = function () {
        document.write("</br>Report is being generated...");
    };
    Manager.prototype.AssignTaskToTeamMembers = function () {
        document.write("</br>Assigned task to team members...");
    };
    Manager.prototype.ApproveLeave = function () {
        document.write("</br>Approved the leave...");
    };
    Manager.prototype.ShowDetails = function () {
        document.write("</br>******************************");
        document.write("</br>Manager of team:" + this.ManagerOfTeam + "</br>First name:" + this.FN + "</br>Last Name:" + this.LN + "</br>Age:" + this.Age + "</br>Height:" + this.Height + "</br>EID:" + this.EID + "</br>Department:" + this.Dept + "</br>Salary:" + this.Salary);
        this.GenerateReport();
        this.AssignTaskToTeamMembers();
        this.ApplyForLeave();
    };
    return Manager;
}(Employee));
var h1 = new Human("Sayali", "Jawre", 21, 150);
h1.ShowDetails();
var e1 = new Employee(123, "IT", 12345, "21/07/2000", "ABC", "XYZ", 50, 155);
e1.ShowDetails();
var m1 = new Manager("Java", 987, "IT", 98765, "23/9/2001", "surabhi", "Kulkarni", 23, 150);
m1.ShowDetails();
