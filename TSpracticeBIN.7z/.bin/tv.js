var TV = /** @class */ (function () {
    function TV(Manufacturer, Size, Price, DisplayType) {
        this.MaxChannels = 20;
        this.Volume = 20;
        this.Manufacturer = Manufacturer;
        this.Size = Size;
        this.Price = Price;
        this.DisplayType = DisplayType;
    }
    /*
    
        setManufacturer(Manufacturer)
        {
            this.Manufacturer=Manufacturer;
        }
        getManufacturer()
        {
            console.log("TV manufacturer is: "+this.Manufacturer);
        }
        setSize(Size)
        {
            this.Size=Size;
        }
        getSize()
        {
            console.log("TV Size is: "+this.Size);
        }
        setPrice(Price)
        {
            this.Price=Price;
        }
        getPrice()
        {
            console.log("TV Price is: "+this.Price);
        }
        setDisplayType(DisplayType)
        {
            this.DisplayType=DisplayType;
        }
        getDisplayType()
        {
            console.log("TV DisplayType is: "+this.DisplayType);
        }
        
    */
    TV.prototype.getData = function () {
        console.log("Data of TV is: Manufacturer- " + this.Manufacturer + "\n Size-" + this.Size + "\n Display Type-" + this.DisplayType + "\n Price-" + this.Price);
    };
    TV.prototype.On = function () {
        console.log("TV gets on...");
    };
    TV.prototype.Off = function () {
        console.log("TV gets off...");
    };
    TV.prototype.ChangeChannel = function (ChannelNumber) {
        if (ChannelNumber > this.MaxChannels) {
            console.log("Please select valid channel number!");
        }
        else {
            console.log("Channel number" + ChannelNumber + " is in display...");
        }
    };
    TV.prototype.IncreaseVolume = function (vol) {
        this.Volume = this.Volume + vol;
        console.log("Volume is increased to " + this.Volume);
    };
    TV.prototype.DecreaseVolume = function (vol) {
        this.Volume = this.Volume - vol;
        console.log("Volume is decreased to " + this.Volume);
    };
    return TV;
}());
var TV1 = new TV("SAMSUNG", "12.5x12.5", "LCD", 15000);
/*TV1.setManufacturer("");
TV1.setSize();
TV1.setPrice();
TV1.setDisplayType();
TV1.getManufacturer();
TV1.getSize();
TV1.getDisplayType();
TV1.getPrice();*/
console.log("hello");
TV1.getData();
TV1.On();
TV1.ChangeChannel(10);
TV1.IncreaseVolume(4);
TV1.DecreaseVolume(9);
TV1.Off();
