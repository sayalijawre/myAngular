class TV
{
    Manufacturer:string;
    Size:number;
    MaxChannels:number=20;
    Price:number;
    DisplayType:string;
    Volume:number=20;
    constructor(Manufacturer,Size,Price,DisplayType){
        this.Manufacturer=Manufacturer;
        this.Size=Size;
        this.Price=Price;
        this.DisplayType=DisplayType;
    }
/*

    setManufacturer(Manufacturer)
    {
        this.Manufacturer=Manufacturer;
    }
    getManufacturer()
    {
        console.log("TV manufacturer is: "+this.Manufacturer);
    }
    setSize(Size)
    {
        this.Size=Size;
    }
    getSize()
    {
        console.log("TV Size is: "+this.Size);
    }
    setPrice(Price)
    {
        this.Price=Price;
    }
    getPrice()
    {
        console.log("TV Price is: "+this.Price);
    }
    setDisplayType(DisplayType)
    {
        this.DisplayType=DisplayType;
    }
    getDisplayType()
    {
        console.log("TV DisplayType is: "+this.DisplayType);
    }
    
*/
    getData(){
        console.log("Data of TV is: Manufacturer- "+this.Manufacturer+"\n Size-"+this.Size+"\n Display Type-"+this.DisplayType+"\n Price-"+this.Price);

    }
    On(){
        console.log("TV gets on...");
    }
    Off(){
        console.log("TV gets off...");
    }
    ChangeChannel(ChannelNumber:number){
        if(ChannelNumber>this.MaxChannels)
        {
            console.log("Please select valid channel number!");
        }
        else
        {
            console.log("Channel number"+ChannelNumber+" is in display...");
        }
    }
    IncreaseVolume(vol:number)
    {
        this.Volume=this.Volume+vol;
        console.log("Volume is increased to "+this.Volume);
    }
    DecreaseVolume(vol:number)
    {
        this.Volume=this.Volume-vol;
        console.log("Volume is decreased to "+this.Volume);
    }
}
var TV1=new TV("SAMSUNG","12.5x12.5","LCD",15000);
/*TV1.setManufacturer("");
TV1.setSize();
TV1.setPrice();
TV1.setDisplayType();
TV1.getManufacturer();
TV1.getSize();
TV1.getDisplayType();
TV1.getPrice();*/
console.log("hello")
TV1.getData();

TV1.On();
TV1.ChangeChannel(10);
TV1.IncreaseVolume(4);
TV1.DecreaseVolume(9);
TV1.Off();
