var Car = /** @class */ (function () {
    function Car() {
        this.speed = 50;
    }
    Car.prototype.start = function (isInNeutral) {
        if (isInNeutral == true) {
            console.log("Car started...");
        }
        else {
            console.log("Bring the car to neutarl state!");
        }
    };
    Car.prototype.stop = function () {
        console.log("Car stopped...");
    };
    Car.prototype.increaseSpeed = function () {
        this.speed = this.speed + 10;
        console.log("Speed increased to: " + this.speed);
    };
    Car.prototype.decreaseSpeed = function () {
        this.speed = this.speed - 10;
        console.log("Speed decreased to: " + this.speed);
    };
    return Car;
}());
var Santro = new Car();
Santro.start(true);
Santro.increaseSpeed();
Santro.decreaseSpeed();
var Audi = new Car();
Audi.start(false);
Audi.increaseSpeed();
Audi.decreaseSpeed();
