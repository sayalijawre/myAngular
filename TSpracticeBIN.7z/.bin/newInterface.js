var sm = {
    realName: "Amitabh",
    superName: "BigB"
};
document.write("" + sm.realName + "</br>" + sm.superName);
var superH = [];
superH.push({ realName: "ABC",
    superName: "XYZ" });
document.write("</br>" + superH[0].realName);
