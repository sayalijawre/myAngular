interface Vehicle{
    drive():any;
}

class Car implements Vehicle
{
    constructor(private wheels:number)
    {}
    
    drive():void{
        document.write("The car drives with "+this.wheels+" no. of wheels!!</br>");
    }
    

}

class Bicycle implements Vehicle
{
    constructor(private wheels:number)
    {}
    
    drive():void{
        document.write("The bicycle drives with "+this.wheels+" no. of wheels!!</br>");
    }
    

}

var car=new Car(4);
var bicycle=new Bicycle(2);
car.drive();
bicycle.drive();