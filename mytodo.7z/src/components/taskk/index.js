import React from 'react';

class Taskk extends React.Component{
    render(){
        return(
            <tr>
                <td>
                    {this.props.tasks}
                </td>
            </tr>
        )
    }
}
export default Taskk;