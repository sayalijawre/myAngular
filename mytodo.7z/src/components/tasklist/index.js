import React from 'react';
import {connect} from 'react-redux';
import Taskk from '../taskk/index.js';

class TaskList extends React.Component{
    render(){
        return(
            <table>
                <thead>
                    <tr>
                        <th>List</th>
                    </tr>
                </thead>
                <tbody>
                    {this.props.tasks.map((task,index)=><Taskk key={index} task={task}/>)}
                </tbody>
            </table>
        
        )
    }
}

function mapStateToProps(state){
    return{
        tasks:state.tasks
    }
}

export default connect(mapStateToProps)(TaskList);