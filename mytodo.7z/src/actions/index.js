export const addTask=(task)=>{
    return{
        type:'Add_Task',
        payload:task
    };
}