export class Table
{
    empId:number;
    empName:string;
    empSal:number;
    empDep:string;
    empjoiningdate:string
}