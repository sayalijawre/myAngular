import { Component } from '@angular/core';
import { NgForm } from '@angular/forms'
import { Form } from './form'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  submitted = false;
  flagBlur: boolean = false;
  categories = ['Grocery', 'Mobile', 'Electronics', 'Cloths'];
  data = new Form(null, '', null, false, this.categories[0], null)
  stores = [{ name: 'D Mart', checked: false }, { name: 'Big Bazar', checked: false }, { name: 'Mega Store', checked: false }, { name: 'Reliance', checked: false }];
  validate() {
    this.flagBlur = true;
  }

  validateCheckbox(): boolean {
    for (let s of this.stores) {
      if (s.checked == true) {
        return true;
      }
    }
    return false;
  }
  storeClicked(s) {

    for (let i = 0; i < this.stores.length; i++) {

      if (this.stores[i].name == s.name) {
        this.stores[i].checked = !this.stores[i].checked;
        console.log(s);
      }
    }
  }

  onSubmit(myForm: NgForm) {
    this.submitted = true


    if (myForm.valid) {
      console.log("Form submitted");
      console.log("Product ID:"+myForm.value.productid);
      console.log("Product Category:"+myForm.value.catgeory);
      console.log("Product Online option:"+myForm.value.onlineoption);
      console.log("Available in stores: ");
      for (let store of this.stores) {
        if (store.checked == true) {
          console.log(store.name);
        }
      }

    }
    else {
      console.log("Form must be filled correctly");
    }

  }
}
